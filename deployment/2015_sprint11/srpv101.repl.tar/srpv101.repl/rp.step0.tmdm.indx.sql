connect to trailsrp
;
create unique index daykey on EAADMIN.TIME_DIMENSION(DAY_KEY)  
;
