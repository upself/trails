connect to trailsst;
drop  table  ASN.IBMSNAP_APPENQ                 ;              
drop  table  ASN.IBMSNAP_APPLEVEL               ;              
drop  table  ASN.IBMSNAP_APPLYMON               ;              
drop  table  ASN.IBMSNAP_APPLYTRACE             ;              
drop  table  ASN.IBMSNAP_APPLYTRAIL             ;              
drop  table  ASN.IBMSNAP_APPPARMS               ;              
drop  table  ASN.IBMSNAP_COMPENSATE             ;              
drop  table  ASN.IBMSNAP_FEEDETL                ;              
drop  table  ASN.IBMSNAP_SUBS_COLS              ;              
drop  table  ASN.IBMSNAP_SUBS_EVENT             ;              
drop  table  ASN.IBMSNAP_SUBS_MEMBR             ;              
drop  table  ASN.IBMSNAP_SUBS_SET               ;              
drop  table  ASN.IBMSNAP_SUBS_STMTS             ;              
drop  table  ASN."asn_diff_table-"               ;              

