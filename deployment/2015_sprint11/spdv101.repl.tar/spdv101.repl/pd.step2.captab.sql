
CONNECT TO TRAILSPD; 


CREATE TABLE NEWASN.IBMSNAP_RESTART(
MAX_COMMITSEQ                   VARCHAR( 16) FOR BIT DATA NOT NULL,
MAX_COMMIT_TIME                 TIMESTAMP NOT NULL,
MIN_INFLIGHTSEQ                 VARCHAR( 16) FOR BIT DATA NOT NULL,
CURR_COMMIT_TIME                TIMESTAMP NOT NULL,
CAPTURE_FIRST_SEQ               VARCHAR( 16) FOR BIT DATA NOT NULL)   IN ASN_TABLES INDEX IN ASN_INDEX;      


INSERT INTO ASN.IBMSNAP_CAPSCHEMAS(CAP_SCHEMA_NAME) VALUES (
'NEWASN')  ;      


CREATE TABLE NEWASN.IBMSNAP_REGISTER(
SOURCE_OWNER                    VARCHAR(128) NOT NULL,
SOURCE_TABLE                    VARCHAR(128) NOT NULL,
SOURCE_VIEW_QUAL                SMALLINT NOT NULL,
GLOBAL_RECORD                   CHAR( 1) NOT NULL,
SOURCE_STRUCTURE                SMALLINT NOT NULL,
SOURCE_CONDENSED                CHAR( 1) NOT NULL,
SOURCE_COMPLETE                 CHAR(  1) NOT NULL,
CD_OWNER                        VARCHAR(128),
CD_TABLE                        VARCHAR(128),
PHYS_CHANGE_OWNER               VARCHAR(128),
PHYS_CHANGE_TABLE               VARCHAR(128),
CD_OLD_SYNCHPOINT               VARCHAR( 16) FOR BIT DATA,
CD_NEW_SYNCHPOINT               VARCHAR( 16) FOR BIT DATA,
DISABLE_REFRESH                 SMALLINT NOT NULL,
CCD_OWNER                       VARCHAR(128),
CCD_TABLE                       VARCHAR(128),
CCD_OLD_SYNCHPOINT              VARCHAR( 16) FOR BIT DATA,
SYNCHPOINT                      VARCHAR( 16) FOR BIT DATA,
SYNCHTIME                       TIMESTAMP,
CCD_CONDENSED                   CHAR(  1),
CCD_COMPLETE                    CHAR(  1),
ARCH_LEVEL                      CHAR(  4) NOT NULL,
DESCRIPTION                     CHAR(254),
BEFORE_IMG_PREFIX               VARCHAR(   4),
CONFLICT_LEVEL                  CHAR(   1),
CHG_UPD_TO_DEL_INS              CHAR(   1),
CHGONLY                         CHAR(   1),
RECAPTURE                       CHAR(   1),
OPTION_FLAGS                    CHAR(   4) NOT NULL,
STOP_ON_ERROR                   CHAR(  1) WITH DEFAULT 'Y',
STATE                           CHAR(  1) WITH DEFAULT 'I',
STATE_INFO                      CHAR(  8))  
 IN ASN_TABLES INDEX IN ASN_INDEX;      


CREATE UNIQUE INDEX NEWASN.IBMSNAP_REGISTERX
ON NEWASN.IBMSNAP_REGISTER(
SOURCE_OWNER                    ASC,
SOURCE_TABLE                    ASC,
SOURCE_VIEW_QUAL                ASC)   ;      


CREATE  INDEX NEWASN.IBMSNAP_REGISTERX1
ON NEWASN.IBMSNAP_REGISTER(
PHYS_CHANGE_OWNER               ASC,
PHYS_CHANGE_TABLE               ASC)   ;      


CREATE  INDEX NEWASN.IBMSNAP_REGISTERX2
ON NEWASN.IBMSNAP_REGISTER(
GLOBAL_RECORD                   ASC)   ;      


ALTER TABLE NEWASN.IBMSNAP_REGISTER VOLATILE CARDINALITY  ;      


CREATE TABLE NEWASN.IBMSNAP_PRUNCNTL(
TARGET_SERVER                   CHAR(18) NOT NULL,
TARGET_OWNER                    VARCHAR(128) NOT NULL,
TARGET_TABLE                    VARCHAR(128) NOT NULL,
SYNCHTIME                       TIMESTAMP,
SYNCHPOINT                      VARCHAR( 16) FOR BIT DATA,
SOURCE_OWNER                    VARCHAR(128) NOT NULL,
SOURCE_TABLE                    VARCHAR(128) NOT NULL,
SOURCE_VIEW_QUAL                SMALLINT NOT NULL,
APPLY_QUAL                      CHAR( 18) NOT NULL,
SET_NAME                        CHAR( 18) NOT NULL,
CNTL_SERVER                     CHAR( 18) NOT NULL,
TARGET_STRUCTURE                SMALLINT NOT NULL,
CNTL_ALIAS                      CHAR( 8),
PHYS_CHANGE_OWNER               VARCHAR(128),
PHYS_CHANGE_TABLE               VARCHAR(128),
MAP_ID                          VARCHAR(10) NOT NULL)   IN ASN_TABLES INDEX IN ASN_INDEX;      


CREATE UNIQUE INDEX NEWASN.IBMSNAP_PRUNCNTLX
ON NEWASN.IBMSNAP_PRUNCNTL(
SOURCE_OWNER                    ASC,
SOURCE_TABLE                    ASC,
SOURCE_VIEW_QUAL                ASC,
APPLY_QUAL                      ASC,
SET_NAME                        ASC,
TARGET_SERVER                   ASC,
TARGET_TABLE                    ASC,
TARGET_OWNER                    ASC)  ;      


CREATE UNIQUE INDEX NEWASN.IBMSNAP_PRUNCNTLX1
ON NEWASN.IBMSNAP_PRUNCNTL(
MAP_ID                          ASC)   ;      


CREATE  INDEX NEWASN.IBMSNAP_PRUNCNTLX2
ON NEWASN.IBMSNAP_PRUNCNTL(
PHYS_CHANGE_OWNER               ASC,
PHYS_CHANGE_TABLE               ASC)   ;      


CREATE  INDEX NEWASN.IBMSNAP_PRUNCNTLX3
ON NEWASN.IBMSNAP_PRUNCNTL(
APPLY_QUAL                      ASC,
SET_NAME                        ASC,
TARGET_SERVER                   ASC)  ;      


ALTER TABLE NEWASN.IBMSNAP_PRUNCNTL VOLATILE CARDINALITY   ;      


CREATE TABLE NEWASN.IBMSNAP_PRUNE_SET(
TARGET_SERVER                   CHAR( 18) NOT NULL,
APPLY_QUAL                      CHAR( 18) NOT NULL,
SET_NAME                        CHAR( 18) NOT NULL,
SYNCHTIME                       TIMESTAMP,
SYNCHPOINT                      VARCHAR( 16) FOR BIT DATA NOT NULL)   IN ASN_TABLES INDEX IN ASN_INDEX;      


CREATE UNIQUE INDEX NEWASN.IBMSNAP_PRUNE_SETX
ON NEWASN.IBMSNAP_PRUNE_SET(
TARGET_SERVER                   ASC,
APPLY_QUAL                      ASC,
SET_NAME                        ASC)   ;      


ALTER TABLE NEWASN.IBMSNAP_PRUNE_SET VOLATILE CARDINALITY  ;      


CREATE TABLE NEWASN.IBMSNAP_CAPTRACE(
OPERATION                       CHAR( 8) NOT NULL,
TRACE_TIME                      TIMESTAMP NOT NULL,
DESCRIPTION                     VARCHAR(1024) NOT NULL)   ;      


CREATE  INDEX NEWASN.IBMSNAP_CAPTRACEX
ON NEWASN.IBMSNAP_CAPTRACE(
TRACE_TIME                      ASC)  ;      


ALTER TABLE NEWASN.IBMSNAP_CAPTRACE VOLATILE CARDINALITY   ;      


CREATE TABLE NEWASN.IBMSNAP_CAPPARMS(
RETENTION_LIMIT                 INT,
LAG_LIMIT                       INT,
COMMIT_INTERVAL                 INT,
PRUNE_INTERVAL                  INT,
TRACE_LIMIT                     INT,
MONITOR_LIMIT                   INT,
MONITOR_INTERVAL                INT,
MEMORY_LIMIT                    SMALLINT,
REMOTE_SRC_SERVER               CHAR( 18),
AUTOPRUNE                       CHAR(  1),
TERM                            CHAR(  1),
AUTOSTOP                        CHAR(  1),
LOGREUSE                        CHAR(  1),
LOGSTDOUT                       CHAR(  1),
SLEEP_INTERVAL                  SMALLINT,
CAPTURE_PATH                    VARCHAR(1040),
STARTMODE                       VARCHAR( 10),
ARCH_LEVEL                      CHAR( 4) NOT NULL WITH DEFAULT '1001',
COMPATIBILITY                   CHAR( 4) NOT NULL WITH DEFAULT '1001',
LOGRDBUFSZ                      INT NOT NULL WITH DEFAULT 256)   IN ASN_TABLES INDEX IN ASN_INDEX;      


CREATE TABLE NEWASN.IBMSNAP_UOW(
IBMSNAP_UOWID                   CHAR( 10) FOR BIT DATA NOT NULL,
IBMSNAP_COMMITSEQ               VARCHAR( 16) FOR BIT DATA NOT NULL,
IBMSNAP_LOGMARKER               TIMESTAMP NOT NULL,
IBMSNAP_AUTHTKN                 VARCHAR(30) NOT NULL,
IBMSNAP_AUTHID                  VARCHAR(128) NOT NULL,
IBMSNAP_REJ_CODE                CHAR(  1) NOT NULL WITH DEFAULT ,
IBMSNAP_APPLY_QUAL              CHAR( 18) NOT NULL WITH DEFAULT )   IN ASN_TABLES INDEX IN ASN_INDEX;      


CREATE UNIQUE INDEX NEWASN.IBMSNAP_UOWX
ON NEWASN.IBMSNAP_UOW(
IBMSNAP_COMMITSEQ               ASC,
IBMSNAP_LOGMARKER               ASC)   ;      


ALTER TABLE NEWASN.IBMSNAP_UOW VOLATILE CARDINALITY  ;      


CREATE TABLE NEWASN.IBMSNAP_CAPENQ(
LOCK_NAME                       CHAR(  9))   IN ASN_TABLES INDEX IN ASN_INDEX;      


CREATE TABLE NEWASN.IBMSNAP_SIGNAL(
SIGNAL_TIME                     TIMESTAMP NOT NULL WITH DEFAULT ,
SIGNAL_TYPE                     VARCHAR( 30) NOT NULL,
SIGNAL_SUBTYPE                  VARCHAR( 30),
SIGNAL_INPUT_IN                 VARCHAR(500),
SIGNAL_STATE                    CHAR( 1) NOT NULL,
SIGNAL_LSN                      VARCHAR( 16) FOR BIT DATA)

 IN ASN_TABLES INDEX IN ASN_INDEX
DATA CAPTURE CHANGES  ;      


CREATE  INDEX NEWASN.IBMSNAP_SIGNALX
ON NEWASN.IBMSNAP_SIGNAL(
SIGNAL_TIME                     ASC)   ;      


ALTER TABLE NEWASN.IBMSNAP_SIGNAL VOLATILE CARDINALITY   ;      


CREATE TABLE NEWASN.IBMSNAP_CAPMON(
MONITOR_TIME                    TIMESTAMP NOT NULL,
RESTART_TIME                    TIMESTAMP NOT NULL,
CURRENT_MEMORY                  INT NOT NULL,
CD_ROWS_INSERTED                INT NOT NULL,
RECAP_ROWS_SKIPPED              INT NOT NULL,
TRIGR_ROWS_SKIPPED              INT NOT NULL,
CHG_ROWS_SKIPPED                INT NOT NULL,
TRANS_PROCESSED                 INT NOT NULL,
TRANS_SPILLED                   INT NOT NULL,
MAX_TRANS_SIZE                  INT NOT NULL,
LOCKING_RETRIES                 INT NOT NULL,
JRN_LIB                         CHAR( 10),
JRN_NAME                        CHAR( 10),
LOGREADLIMIT                    INT NOT NULL,
CAPTURE_IDLE                    INT NOT NULL,
SYNCHTIME                       TIMESTAMP NOT NULL,
CURRENT_LOG_TIME                TIMESTAMP NOT NULL WITH DEFAULT ,
LAST_EOL_TIME                   TIMESTAMP,
RESTART_SEQ                     VARCHAR( 16) FOR BIT DATA NOT NULL WITH DEFAULT ,
CURRENT_SEQ                     VARCHAR( 16) FOR BIT DATA NOT NULL WITH DEFAULT ,
RESTART_MAXCMTSEQ               VARCHAR( 16) FOR BIT DATA NOT NULL WITH DEFAULT ,
LOGREAD_API_TIME                INT,
NUM_LOGREAD_CALLS               INT)   IN ASN_TABLES INDEX IN ASN_INDEX;      


CREATE UNIQUE INDEX NEWASN.IBMSNAP_CAPMONX
ON NEWASN.IBMSNAP_CAPMON(
MONITOR_TIME                    ASC)  ;      


ALTER TABLE NEWASN.IBMSNAP_CAPMON VOLATILE CARDINALITY   ;      


CREATE TABLE NEWASN.IBMSNAP_PRUNE_LOCK(
DUMMY                           CHAR( 1))   IN ASN_TABLES INDEX IN ASN_INDEX;      


CREATE TABLE NEWASN.IBMQREP_IGNTRAN(
AUTHID                          CHAR(128),
AUTHTOKEN                       CHAR(30),
PLANNAME                        CHAR(8),
IGNTRANTRC                      CHAR(1) NOT NULL WITH DEFAULT 'N')   IN ASN_TABLES INDEX IN ASN_INDEX;      


CREATE UNIQUE INDEX NEWASN.IGNTRANX
ON NEWASN.IBMQREP_IGNTRAN(
AUTHID                          ASC,
AUTHTOKEN                       ASC,
PLANNAME                        ASC)  ;      


CREATE TABLE NEWASN.IBMQREP_IGNTRANTRC(
IGNTRAN_TIME                    TIMESTAMP NOT NULL WITH DEFAULT ,
AUTHID                          CHAR(128),
AUTHTOKEN                       CHAR( 30),
PLANNAME                        CHAR(  8),
TRANSID                         CHAR( 10) FOR BIT DATA NOT NULL,
COMMITLSN                       VARCHAR( 16) FOR BIT DATA)   IN ASN_TABLES INDEX IN ASN_INDEX;      


CREATE  INDEX NEWASN.IGNTRCX
ON NEWASN.IBMQREP_IGNTRANTRC(
IGNTRAN_TIME                    ASC)   ;      


CREATE TABLE NEWASN.IBMQREP_TABVERSION(
LSN                             VARCHAR( 16) FOR BIT DATA NOT NULL,
TABLEID1                        SMALLINT NOT NULL,
TABLEID2                        SMALLINT NOT NULL,
VERSION                         INTEGER NOT NULL,
SOURCE_OWNER                    VARCHAR(128) NOT NULL,
SOURCE_NAME                     VARCHAR(128) NOT NULL,
VERSION_TIME                    TIMESTAMP NOT NULL WITH DEFAULT )   IN ASN_TABLES INDEX IN ASN_INDEX;      


CREATE UNIQUE INDEX NEWASN.IBMQREP_TABVERSIOX
ON NEWASN.IBMQREP_TABVERSION(
LSN                             ASC,
TABLEID1                        ASC,
TABLEID2                        ASC,
VERSION                         ASC)   ;      


CREATE  INDEX NEWASN.IX2TABVERSION
ON NEWASN.IBMQREP_TABVERSION(
TABLEID1                        ASC,
TABLEID2                        ASC);                


CREATE  INDEX NEWASN.IX3TABVERSION
ON NEWASN.IBMQREP_TABVERSION(
SOURCE_OWNER                    ASC,
SOURCE_NAME                     ASC);                


CREATE TABLE NEWASN.IBMQREP_COLVERSION(
LSN                             VARCHAR( 16) FOR BIT DATA NOT NULL,
TABLEID1                        SMALLINT NOT NULL,
TABLEID2                        SMALLINT NOT NULL,
POSITION                        SMALLINT NOT NULL,
NAME                            VARCHAR(128) NOT NULL,
TYPE                            SMALLINT NOT NULL,
LENGTH                          INTEGER NOT NULL,
NULLS                           CHAR(  1) NOT NULL,
DEFAULT                         VARCHAR(1536),
CODEPAGE                        INTEGER,
SCALE                           INTEGER,
VERSION_TIME                    TIMESTAMP NOT NULL WITH DEFAULT )   IN ASN_TABLES INDEX IN ASN_INDEX;      


CREATE UNIQUE INDEX NEWASN.IBMQREP_COLVERSIOX
ON NEWASN.IBMQREP_COLVERSION(
LSN                             ASC,
TABLEID1                        ASC,
TABLEID2                        ASC,
POSITION                        ASC);                


CREATE  INDEX NEWASN.IX2COLVERSION
ON NEWASN.IBMQREP_COLVERSION(
TABLEID1                        ASC,
TABLEID2                        ASC);                


CREATE TABLE NEWASN.IBMQREP_PART_HIST(
LSN                             VARCHAR(16) FOR BIT DATA NOT NULL,
HISTORY_TIME                    TIMESTAMP NOT NULL,
TABSCHEMA                       VARCHAR(128) NOT NULL,
TABNAME                         VARCHAR(128) NOT NULL,
DATAPARTITIONID                 INT NOT NULL,
TBSPACEID                       INT NOT NULL,
PARTITIONOBJECTID               INT NOT NULL,
PRIMARY KEY (LSN,TABSCHEMA,TABNAME,DATAPARTITIONID,TBSPACEID,PARTITIONOBJECTID)
)   IN ASN_TABLES INDEX IN ASN_INDEX;      


CREATE  INDEX NEWASN.IX1PARTHISTORY
ON NEWASN.IBMQREP_PART_HIST(
TABSCHEMA                       ASC,
TABNAME                         ASC,
LSN                             ASC);                


INSERT INTO NEWASN.IBMSNAP_CAPPARMS(
RETENTION_LIMIT,
LAG_LIMIT,
COMMIT_INTERVAL,
PRUNE_INTERVAL,
TRACE_LIMIT,
MONITOR_LIMIT,
MONITOR_INTERVAL,
MEMORY_LIMIT,
SLEEP_INTERVAL,
AUTOPRUNE,
TERM,
AUTOSTOP,
LOGREUSE,
LOGSTDOUT,
CAPTURE_PATH,
STARTMODE,
COMPATIBILITY)
VALUES (
10080,
10080,
30,
300,
10080,
10080,
300,
32,
5,
'Y',
'Y',
'N',
'N',
'N',
NULL,
'WARMSI',
'1001'
)   ;      


 COMMIT   ;      

-- CONNECT TO TRAILSPD ;                                  
                                                          
                                                                                 
CREATE TABLE ASN.IBMSNAP_RESTART(                                                
MAX_COMMITSEQ                   VARCHAR( 16) FOR BIT DATA NOT NULL,              
MAX_COMMIT_TIME                 TIMESTAMP NOT NULL,                              
MIN_INFLIGHTSEQ                 VARCHAR( 16) FOR BIT DATA NOT NULL,              
CURR_COMMIT_TIME                TIMESTAMP NOT NULL,                              
CAPTURE_FIRST_SEQ               VARCHAR( 16) FOR BIT DATA NOT NULL)
IN ASN_TABLES INDEX IN ASN_INDEX;             
                                                                                 
                                                                                 
CREATE TABLE ASN.IBMSNAP_CAPSCHEMAS(                                             
CAP_SCHEMA_NAME                 VARCHAR(128) NOT NULL)
IN ASN_TABLES INDEX IN ASN_INDEX;                          
                                                                                 
                                                                                 
CREATE UNIQUE INDEX ASN.IBMSNAP_CAPSCHEMASX                                      
ON ASN.IBMSNAP_CAPSCHEMAS(                                                       
CAP_SCHEMA_NAME                 ASC);                                            
                                                                                 
                                                                                 
ALTER TABLE ASN.IBMSNAP_CAPSCHEMAS VOLATILE CARDINALITY;                         
                                                                                 
                                                                                 
INSERT INTO ASN.IBMSNAP_CAPSCHEMAS(CAP_SCHEMA_NAME) VALUES (                     
'ASN');                                                                          
                                                                                 
                                                                                 
CREATE TABLE ASN.IBMSNAP_REGISTER(                                               
SOURCE_OWNER                    VARCHAR(128) NOT NULL,                           
SOURCE_TABLE                    VARCHAR(128) NOT NULL,                           
SOURCE_VIEW_QUAL                SMALLINT NOT NULL,                               
GLOBAL_RECORD                   CHAR( 1) NOT NULL,                               
SOURCE_STRUCTURE                SMALLINT NOT NULL,                               
SOURCE_CONDENSED                CHAR( 1) NOT NULL,                               
SOURCE_COMPLETE                 CHAR(  1) NOT NULL,                              
CD_OWNER                        VARCHAR(128),                                    
CD_TABLE                        VARCHAR(128),                                    
PHYS_CHANGE_OWNER               VARCHAR(128),                                    
PHYS_CHANGE_TABLE               VARCHAR(128),                                    
CD_OLD_SYNCHPOINT               VARCHAR( 16) FOR BIT DATA,                       
CD_NEW_SYNCHPOINT               VARCHAR( 16) FOR BIT DATA,                       
DISABLE_REFRESH                 SMALLINT NOT NULL,                               
CCD_OWNER                       VARCHAR(128),                                    
CCD_TABLE                       VARCHAR(128),                                    
CCD_OLD_SYNCHPOINT              VARCHAR( 16) FOR BIT DATA,                       
SYNCHPOINT                      VARCHAR( 16) FOR BIT DATA,                       
SYNCHTIME                       TIMESTAMP,                                       
CCD_CONDENSED                   CHAR(  1),                                       
CCD_COMPLETE                    CHAR(  1),                                       
ARCH_LEVEL                      CHAR(  4) NOT NULL,                              
DESCRIPTION                     CHAR(254),                                       
BEFORE_IMG_PREFIX               VARCHAR(   4),                                   
CONFLICT_LEVEL                  CHAR(   1),                                      
CHG_UPD_TO_DEL_INS              CHAR(   1),                                      
CHGONLY                         CHAR(   1),                                      
RECAPTURE                       CHAR(   1),                                      
OPTION_FLAGS                    CHAR(   4) NOT NULL,                             
STOP_ON_ERROR                   CHAR(  1) WITH DEFAULT 'Y',                      
STATE                           CHAR(  1) WITH DEFAULT 'I',                      
STATE_INFO                      CHAR(  8));                                      
                                                                                 
                                                                                 
CREATE UNIQUE INDEX ASN.IBMSNAP_REGISTERX                                        
ON ASN.IBMSNAP_REGISTER(                                                         
SOURCE_OWNER                    ASC,                                             
SOURCE_TABLE                    ASC,                                             
SOURCE_VIEW_QUAL                ASC);                                            
                                                                                 
                                                                                 
CREATE  INDEX ASN.IBMSNAP_REGISTERX1                                             
ON ASN.IBMSNAP_REGISTER(                                                         
PHYS_CHANGE_OWNER               ASC,                                             
PHYS_CHANGE_TABLE               ASC);                                            
                                                                                 
                                                                                 
CREATE  INDEX ASN.IBMSNAP_REGISTERX2                                             
ON ASN.IBMSNAP_REGISTER(                                                         
GLOBAL_RECORD                   ASC);                                            
                                                                                 
                                                                                 
ALTER TABLE ASN.IBMSNAP_REGISTER VOLATILE CARDINALITY;                           
                                                                                 
                                                                                 
CREATE TABLE ASN.IBMSNAP_PRUNCNTL(                                               
TARGET_SERVER                   CHAR(18) NOT NULL,                               
TARGET_OWNER                    VARCHAR(128) NOT NULL,                           
TARGET_TABLE                    VARCHAR(128) NOT NULL,                           
SYNCHTIME                       TIMESTAMP,                                       
SYNCHPOINT                      VARCHAR( 16) FOR BIT DATA,                       
SOURCE_OWNER                    VARCHAR(128) NOT NULL,                           
SOURCE_TABLE                    VARCHAR(128) NOT NULL,                           
SOURCE_VIEW_QUAL                SMALLINT NOT NULL,                               
APPLY_QUAL                      CHAR( 18) NOT NULL,                              
SET_NAME                        CHAR( 18) NOT NULL,                              
CNTL_SERVER                     CHAR( 18) NOT NULL,                              
TARGET_STRUCTURE                SMALLINT NOT NULL,                               
CNTL_ALIAS                      CHAR( 8),                                        
PHYS_CHANGE_OWNER               VARCHAR(128),                                    
PHYS_CHANGE_TABLE               VARCHAR(128),                                    
MAP_ID                          VARCHAR(10) NOT NULL)
IN ASN_TABLES INDEX IN ASN_INDEX;                           
                                                                                 
                                                                                 
CREATE UNIQUE INDEX ASN.IBMSNAP_PRUNCNTLX                                        
ON ASN.IBMSNAP_PRUNCNTL(                                                         
SOURCE_OWNER                    ASC,                                             
SOURCE_TABLE                    ASC,                                             
SOURCE_VIEW_QUAL                ASC,                                             
APPLY_QUAL                      ASC,                                             
SET_NAME                        ASC,                                             
TARGET_SERVER                   ASC,                                             
TARGET_TABLE                    ASC,                                             
TARGET_OWNER                    ASC);                                            
                                                                                 
                                                                                 
CREATE UNIQUE INDEX ASN.IBMSNAP_PRUNCNTLX1                                       
ON ASN.IBMSNAP_PRUNCNTL(                                                         
MAP_ID                          ASC);                                            
                                                                                 
                                                                                 
CREATE  INDEX ASN.IBMSNAP_PRUNCNTLX2                                             
ON ASN.IBMSNAP_PRUNCNTL(                                                         
PHYS_CHANGE_OWNER               ASC,                                             
PHYS_CHANGE_TABLE               ASC);                                            
                                                                                 
                                                                                 
CREATE  INDEX ASN.IBMSNAP_PRUNCNTLX3                                             
ON ASN.IBMSNAP_PRUNCNTL(                                                         
APPLY_QUAL                      ASC,                                             
SET_NAME                        ASC,                                             
TARGET_SERVER                   ASC);                                            
                                                                                 
                                                                                 
ALTER TABLE ASN.IBMSNAP_PRUNCNTL VOLATILE CARDINALITY;                           
                                                                                 
                                                                                 
CREATE TABLE ASN.IBMSNAP_PRUNE_SET(                                              
TARGET_SERVER                   CHAR( 18) NOT NULL,                              
APPLY_QUAL                      CHAR( 18) NOT NULL,                              
SET_NAME                        CHAR( 18) NOT NULL,                              
SYNCHTIME                       TIMESTAMP,                                       
SYNCHPOINT                      VARCHAR( 16) FOR BIT DATA NOT NULL)
IN ASN_TABLES INDEX IN ASN_INDEX;             
                                                                                 
                                                                                 
CREATE UNIQUE INDEX ASN.IBMSNAP_PRUNE_SETX                                       
ON ASN.IBMSNAP_PRUNE_SET(                                                        
TARGET_SERVER                   ASC,                                             
APPLY_QUAL                      ASC,                                             
SET_NAME                        ASC);                                            
                                                                                 
                                                                                 
ALTER TABLE ASN.IBMSNAP_PRUNE_SET VOLATILE CARDINALITY;                          
                                                                                 
                                                                                 
CREATE TABLE ASN.IBMSNAP_CAPTRACE(                                               
OPERATION                       CHAR( 8) NOT NULL,                               
TRACE_TIME                      TIMESTAMP NOT NULL,                              
DESCRIPTION                     VARCHAR(1024) NOT NULL)
IN ASN_TABLES INDEX IN ASN_INDEX;                         
                                                                                 
                                                                                 
CREATE  INDEX ASN.IBMSNAP_CAPTRACEX                                              
ON ASN.IBMSNAP_CAPTRACE(                                                         
TRACE_TIME                      ASC);                                            
                                                                                 
                                                                                 
ALTER TABLE ASN.IBMSNAP_CAPTRACE VOLATILE CARDINALITY;                           
                                                                                 
                                                                                 
CREATE TABLE ASN.IBMSNAP_CAPPARMS(                                               
RETENTION_LIMIT                 INT,                                             
LAG_LIMIT                       INT,                                             
COMMIT_INTERVAL                 INT,                                             
PRUNE_INTERVAL                  INT,                                             
TRACE_LIMIT                     INT,                                             
MONITOR_LIMIT                   INT,                                             
MONITOR_INTERVAL                INT,                                             
MEMORY_LIMIT                    SMALLINT,                                        
REMOTE_SRC_SERVER               CHAR( 18),                                       
AUTOPRUNE                       CHAR(  1),                                       
TERM                            CHAR(  1),                                       
AUTOSTOP                        CHAR(  1),                                       
LOGREUSE                        CHAR(  1),                                       
LOGSTDOUT                       CHAR(  1),                                       
SLEEP_INTERVAL                  SMALLINT,                                        
CAPTURE_PATH                    VARCHAR(1040),                                   
STARTMODE                       VARCHAR( 10),                                    
ARCH_LEVEL                      CHAR( 4) NOT NULL WITH DEFAULT '1001',           
COMPATIBILITY                   CHAR( 4) NOT NULL WITH DEFAULT '1001',           
LOGRDBUFSZ                      INT NOT NULL WITH DEFAULT 256)
IN ASN_TABLES INDEX IN ASN_INDEX;                  
                                                                                 
                                                                                 
CREATE TABLE ASN.IBMSNAP_UOW(                                                    
IBMSNAP_UOWID                   CHAR( 10) FOR BIT DATA NOT NULL,                 
IBMSNAP_COMMITSEQ               VARCHAR( 16) FOR BIT DATA NOT NULL,              
IBMSNAP_LOGMARKER               TIMESTAMP NOT NULL,                              
IBMSNAP_AUTHTKN                 VARCHAR(30) NOT NULL,                            
IBMSNAP_AUTHID                  VARCHAR(128) NOT NULL,                           
IBMSNAP_REJ_CODE                CHAR(  1) NOT NULL WITH DEFAULT ,                
IBMSNAP_APPLY_QUAL              CHAR( 18) NOT NULL WITH DEFAULT )
IN ASN_TABLES INDEX IN ASN_INDEX;               
                                                                                 
                                                                                 
CREATE UNIQUE INDEX ASN.IBMSNAP_UOWX                                             
ON ASN.IBMSNAP_UOW(                                                              
IBMSNAP_COMMITSEQ               ASC,                                             
IBMSNAP_LOGMARKER               ASC);                                            
                                                                                 
                                                                                 
ALTER TABLE ASN.IBMSNAP_UOW VOLATILE CARDINALITY;                                
                                                                                 
                                                                                 
CREATE TABLE ASN.IBMSNAP_CAPENQ(                                                 
LOCK_NAME                       CHAR(  9))
IN ASN_TABLES INDEX IN ASN_INDEX;                                      
                                                                                 
                                                                                 
CREATE TABLE ASN.IBMSNAP_SIGNAL(                                                 
SIGNAL_TIME                     TIMESTAMP NOT NULL WITH DEFAULT ,                
SIGNAL_TYPE                     VARCHAR( 30) NOT NULL,                           
SIGNAL_SUBTYPE                  VARCHAR( 30),                                    
SIGNAL_INPUT_IN                 VARCHAR(500),                                    
SIGNAL_STATE                    CHAR( 1) NOT NULL,                               
SIGNAL_LSN                      VARCHAR( 16) FOR BIT DATA)
IN ASN_TABLES INDEX IN ASN_INDEX                         
DATA CAPTURE CHANGES;                                                            
                                                                                 
                                                                                 
CREATE  INDEX ASN.IBMSNAP_SIGNALX                                                
ON ASN.IBMSNAP_SIGNAL(                                                           
SIGNAL_TIME                     ASC);                                            
                                                                                 
                                                                                 
ALTER TABLE ASN.IBMSNAP_SIGNAL VOLATILE CARDINALITY;                             
                                                                                 
                                                                                 
CREATE TABLE ASN.IBMSNAP_CAPMON(                                                 
MONITOR_TIME                    TIMESTAMP NOT NULL,                              
RESTART_TIME                    TIMESTAMP NOT NULL,                              
CURRENT_MEMORY                  INT NOT NULL,                                    
CD_ROWS_INSERTED                INT NOT NULL,                                    
RECAP_ROWS_SKIPPED              INT NOT NULL,                                    
TRIGR_ROWS_SKIPPED              INT NOT NULL,                                    
CHG_ROWS_SKIPPED                INT NOT NULL,                                    
TRANS_PROCESSED                 INT NOT NULL,                                    
TRANS_SPILLED                   INT NOT NULL,                                    
MAX_TRANS_SIZE                  INT NOT NULL,                                    
LOCKING_RETRIES                 INT NOT NULL,                                    
JRN_LIB                         CHAR( 10),                                       
JRN_NAME                        CHAR( 10),                                       
LOGREADLIMIT                    INT NOT NULL,                                    
CAPTURE_IDLE                    INT NOT NULL,                                    
SYNCHTIME                       TIMESTAMP NOT NULL,                              
CURRENT_LOG_TIME                TIMESTAMP NOT NULL WITH DEFAULT ,                
LAST_EOL_TIME                   TIMESTAMP,                                       
RESTART_SEQ                     VARCHAR( 16) FOR BIT DATA NOT NULL WITH DEFAULT ,
CURRENT_SEQ                     VARCHAR( 16) FOR BIT DATA NOT NULL WITH DEFAULT ,
RESTART_MAXCMTSEQ               VARCHAR( 16) FOR BIT DATA NOT NULL WITH DEFAULT ,
LOGREAD_API_TIME                INT,                                             
NUM_LOGREAD_CALLS               INT)
IN ASN_TABLES INDEX IN ASN_INDEX;                                            
                                                                                 
                                                                                 
CREATE UNIQUE INDEX ASN.IBMSNAP_CAPMONX                                          
ON ASN.IBMSNAP_CAPMON(                                                           
MONITOR_TIME                    ASC);                                            
                                                                                 
                                                                                 
ALTER TABLE ASN.IBMSNAP_CAPMON VOLATILE CARDINALITY;                             
                                                                                 
                                                                                 
CREATE TABLE ASN.IBMSNAP_PRUNE_LOCK(                                             
DUMMY                           CHAR( 1))  
IN ASN_TABLES INDEX IN ASN_INDEX;                                       
                                                                                 
                                                                                 
CREATE TABLE ASN.IBMQREP_IGNTRAN(                                                
AUTHID                          CHAR(128),                                       
AUTHTOKEN                       CHAR(30),                                        
PLANNAME                        CHAR(8),                                         
IGNTRANTRC                      CHAR(1) NOT NULL WITH DEFAULT 'N')

  IN ASN_TABLES INDEX IN ASN_INDEX;              
                                                                                 
                                                                                 
CREATE UNIQUE INDEX ASN.IGNTRANX                                                 
ON ASN.IBMQREP_IGNTRAN(                                                          
AUTHID                          ASC,                                             
AUTHTOKEN                       ASC,                                             
PLANNAME                        ASC);                                            
                                                                                 
                                                                                 
CREATE TABLE ASN.IBMQREP_IGNTRANTRC(                                             
IGNTRAN_TIME                    TIMESTAMP NOT NULL WITH DEFAULT ,                
AUTHID                          CHAR(128),                                       
AUTHTOKEN                       CHAR( 30),                                       
PLANNAME                        CHAR(  8),                                       
TRANSID                         CHAR( 10) FOR BIT DATA NOT NULL,                 
COMMITLSN                       VARCHAR( 16) FOR BIT DATA)
IN ASN_TABLES INDEX IN ASN_INDEX  
;                      
                                                                                 
                                                                                 
CREATE  INDEX ASN.IGNTRCX                                                        
ON ASN.IBMQREP_IGNTRANTRC(                                                       
IGNTRAN_TIME                    ASC);                                            
                                                                                 
                                                                                 
CREATE TABLE ASN.IBMQREP_TABVERSION(                                             
LSN                             VARCHAR( 16) FOR BIT DATA NOT NULL,              
TABLEID1                        SMALLINT NOT NULL,                               
TABLEID2                        SMALLINT NOT NULL,                               
VERSION                         INTEGER NOT NULL,                                
SOURCE_OWNER                    VARCHAR(128) NOT NULL,                           
SOURCE_NAME                     VARCHAR(128) NOT NULL,                           
VERSION_TIME                    TIMESTAMP NOT NULL WITH DEFAULT )
  IN ASN_TABLES INDEX IN ASN_INDEX;               
                                                                                 
                                                                                 
CREATE UNIQUE INDEX ASN.IBMQREP_TABVERSIOX                                       
ON ASN.IBMQREP_TABVERSION(                                                       
LSN                             ASC,                                             
TABLEID1                        ASC,                                             
TABLEID2                        ASC,                                             
VERSION                         ASC);                                            
                                                                                 
                                                                                 
CREATE  INDEX ASN.IX2TABVERSION                                                  
ON ASN.IBMQREP_TABVERSION(                                                       
TABLEID1                        ASC,                                             
TABLEID2                        ASC);                                            
                                                                                 
                                                                                 
CREATE  INDEX ASN.IX3TABVERSION                                                  
ON ASN.IBMQREP_TABVERSION(                                                       
SOURCE_OWNER                    ASC,                                             
SOURCE_NAME                     ASC);                                            
                                                                                 
                                                                                 
CREATE TABLE ASN.IBMQREP_COLVERSION(                                             
LSN                             VARCHAR( 16) FOR BIT DATA NOT NULL,              
TABLEID1                        SMALLINT NOT NULL,                               
TABLEID2                        SMALLINT NOT NULL,                               
POSITION                        SMALLINT NOT NULL,                               
NAME                            VARCHAR(128) NOT NULL,                           
TYPE                            SMALLINT NOT NULL,                               
LENGTH                          INTEGER NOT NULL,                                
NULLS                           CHAR(  1) NOT NULL,                              
DEFAULT                         VARCHAR(1536),                                   
CODEPAGE                        INTEGER,                                         
SCALE                           INTEGER,                                         
VERSION_TIME                    TIMESTAMP NOT NULL WITH DEFAULT )

   IN ASN_TABLES INDEX IN ASN_INDEX;               
                                                                                 
                                                                                 
CREATE UNIQUE INDEX ASN.IBMQREP_COLVERSIOX                                       
ON ASN.IBMQREP_COLVERSION(                                                       
LSN                             ASC,                                             
TABLEID1                        ASC,                                             
TABLEID2                        ASC,                                             
POSITION                        ASC);                                            
                                                                                 
                                                                                 
CREATE  INDEX ASN.IX2COLVERSION                                                  
ON ASN.IBMQREP_COLVERSION(                                                       
TABLEID1                        ASC,                                             
TABLEID2                        ASC);                                            
                                                                                 
                                                                                 
CREATE TABLE ASN.IBMQREP_PART_HIST(                                              
LSN                             VARCHAR(16) FOR BIT DATA NOT NULL,               
HISTORY_TIME                    TIMESTAMP NOT NULL,                              
TABSCHEMA                       VARCHAR(128) NOT NULL,                           
TABNAME                         VARCHAR(128) NOT NULL,                           
DATAPARTITIONID                 INT NOT NULL,                                    
TBSPACEID                       INT NOT NULL,                                    
PARTITIONOBJECTID               INT NOT NULL,                                    
PRIMARY KEY (LSN,TABSCHEMA,TABNAME,DATAPARTITIONID,TBSPACEID,PARTITIONOBJECTID)  
)   IN ASN_TABLES INDEX IN ASN_INDEX;                                                                               
                                                                                 
                                                                                 
CREATE  INDEX ASN.IX1PARTHISTORY                                                 
ON ASN.IBMQREP_PART_HIST(                                                        
TABSCHEMA                       ASC,                                             
TABNAME                         ASC,                                             
LSN                             ASC);                                            
                                                                                 
                                                                                 
INSERT INTO ASN.IBMSNAP_CAPPARMS(                                                
RETENTION_LIMIT,                                                                 
LAG_LIMIT,                                                                       
COMMIT_INTERVAL,                                                                 
PRUNE_INTERVAL,                                                                  
TRACE_LIMIT,                                                                     
MONITOR_LIMIT,                                                                   
MONITOR_INTERVAL,                                                                
MEMORY_LIMIT,                                                                    
SLEEP_INTERVAL,                                                                  
AUTOPRUNE,                                                                       
TERM,                                                                            
AUTOSTOP,                                                                        
LOGREUSE,                                                                        
LOGSTDOUT,                                                                       
CAPTURE_PATH,                                                                    
STARTMODE,                                                                       
COMPATIBILITY)                                                                   
VALUES (                                                                         
10080,                                                                           
10080,                                                                           
30,                                                                              
300,                                                                             
10080,                                                                           
10080,                                                                           
300,                                                                             
32,                                                                              
5,                                                                               
'Y',                                                                             
'Y',                                                                             
'N',                                                                             
'N',                                                                             
'N',                                                                             
NULL,                                                                            
'WARMSI',                                                                        
'1001'                                                                           
);                                                                               
                                                                                 
                                                                                 
 COMMIT;                                                                       
CONNECT RESET;
                                                                                 
                                                                                 
                                     
