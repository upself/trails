
 connect to trailspd;
 drop table  NEWASN.IBMQREP_COLVERSION                ;        
 drop table  NEWASN.IBMQREP_IGNTRAN                   ;        
 drop table  NEWASN.IBMQREP_IGNTRANTRC                ;        
 drop table  NEWASN.IBMQREP_PART_HIST                 ;        
 drop table  NEWASN.IBMQREP_TABVERSION                ;        
 drop table  NEWASN.IBMSNAP_CAPENQ                    ;        
 drop table  NEWASN.IBMSNAP_CAPMON                    ;        
 drop table  NEWASN.IBMSNAP_CAPPARMS                  ;        
 drop table  NEWASN.IBMSNAP_CAPTRACE                  ;        
 drop table  NEWASN.IBMSNAP_PRUNCNTL                  ;        
 drop table  NEWASN.IBMSNAP_PRUNE_LOCK                ;        
 drop table  NEWASN.IBMSNAP_PRUNE_SET                 ;        
 drop table  NEWASN.IBMSNAP_REGISTER                  ;        
 drop table  NEWASN.IBMSNAP_RESTART                   ;        
 drop table  NEWASN.IBMSNAP_SIGNAL                    ;        
 drop table  NEWASN.IBMSNAP_UOW                       ;        


drop table  ASN.IBMQREP_COLVERSION                 ;
drop table  ASN.IBMQREP_IGNTRAN                   ;
drop table  ASN.IBMQREP_IGNTRANTRC                ;
drop table  ASN.IBMQREP_PART_HIST                 ;
drop table  ASN.IBMQREP_TABVERSION                ;
drop table  ASN.IBMSNAP_CAPENQ                    ;
drop table  ASN.IBMSNAP_CAPMON                    ;
drop table  ASN.IBMSNAP_CAPPARMS                  ;
drop table  ASN.IBMSNAP_CAPSCHEMAS                ;
drop table  ASN.IBMSNAP_CAPTRACE                  ;
drop table  ASN.IBMSNAP_PRUNCNTL                  ;
drop table  ASN.IBMSNAP_PRUNE_LOCK                ;
drop table  ASN.IBMSNAP_PRUNE_SET                 ;
drop table  ASN.IBMSNAP_REGISTER                  ;
drop table  ASN.IBMSNAP_RESTART                   ;
drop table  ASN.IBMSNAP_SIGNAL                    ;
drop table  ASN.IBMSNAP_UOW                       ;
connect reset;
terminate;
