drop table asn."diff_table-";
