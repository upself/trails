CONNECT TO TRAILSPD 
;                                                                                                                               
create unique index daykey on EAADMIN.TIME_DIMENSION(DAY_KEY) 
; 
 